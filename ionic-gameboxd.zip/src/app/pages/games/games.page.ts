import { Component, OnInit } from '@angular/core';
import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonCard,
  IonCardContent,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonSkeletonText,
  IonText,
  IonIcon,
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { logoIonic, heartOutline, settingsSharp } from 'ionicons/icons';
import { Rawg } from '../../services/rawg';
import { CommonModule } from '@angular/common';
import { AlertController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-games',
  templateUrl: './games.page.html',
  styleUrls: ['./games.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonCard,
    IonCardContent,
    IonInfiniteScroll,
    IonInfiniteScrollContent,
    IonSkeletonText,
    IonText,
    IonIcon,
    ,
  ],
})
export class GamesPage implements OnInit {
  games: any[] = [];
  page = 1;
  loading = true;
  errorMessage = '';
  hasError = false;

  constructor(
    private rawg: Rawg,
    private alertController: AlertController,
    private router: Router,
  ) {}

  ngOnInit() {
    this.loadGames();
  }
  loadGames() {
    this.rawg.getGames(this.page).subscribe({
      next: (data: any) => {
        this.games = [...this.games, ...data.results];
        this.loading = false;
      },
      error: async (error) => {
        console.error(error);
        this.loading = false;
        this.hasError = true;
        await this.showErrorAlert(
          'Não foi possível carregar os jogos. Por favor, tente novamente mais tarde.',
        );
      },
    });
  }

  loadMore(event: any) {
    this.page++;

    this.rawg.getGames(this.page).subscribe({
      next: (data: any) => {
        this.games = [...this.games, ...data.results];
        event.target.complete();
      },
      error: async (error) => {
        console.error(error);
        this.hasError = true;
        await this.showErrorAlert(
          'Não foi possível carregar os jogos. Por favor, tente novamente mais tarde.',
        );
        event.target.complete();
      },
    });
  }

  async showErrorAlert(message: string) {
    const alert = await this.alertController.create({
      header: 'Erro',
      message,
      buttons: [
        { text: 'OK', role: 'cancel' },
        { text: 'Tentar novamente', handler: () => this.loadGames() },
      ],
    });
    await alert.present();
  }

  get skeletonArray() {
    const columns = Math.floor(window.innerWidth / 250);
    return Array(columns * 3);
  }

  openGameDetails(gameId: number) {
    this.router.navigate([`/game/${gameId}`]);
  }
}
